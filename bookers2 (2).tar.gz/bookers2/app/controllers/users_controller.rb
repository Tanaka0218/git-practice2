class UsersController < ApplicationController
  def index
     @books = Book.all
      @books = Book.includes(:user).all
  end

  def show
    @user = User.find(params[:id])
      @user = User.find_by(id: params[:id])
       @books = @user.books
  end

  def edit
    @user = User.find(params[:id])
    if @user == current_user
        render "edit"
    else
      redirect_to user_path(current_user)
    end
  end
end
